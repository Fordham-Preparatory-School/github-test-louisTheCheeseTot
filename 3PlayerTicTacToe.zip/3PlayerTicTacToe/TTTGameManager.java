import java.util.Scanner;

public class TTTGameManager 
{
    private static TTTPlayer[] players = new TTTPlayer[3];
    private static int curPlayer = 0;
    public static Pieces[][] board = {
        {Pieces.empty},
        {Pieces.empty,Pieces.empty,Pieces.empty},
        {Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty},
        {Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty},
        {Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty}
    };
    private static boolean finished;

    public static void main(String[] args)
    {
        InitializePlayers();

        boolean gameLooping = true;

        while(gameLooping)
        {
            RefreshBoard();

            while (!finished) 
            { 
                TTTVisuals.PrintBoard();
                PlacePiece();
            }
    
            TTTVisuals.PrintBoard();
            System.out.println(players[curPlayer].getName() + " WON THE GAME!!!");

            gameLooping = Rematch();
        }

    }

    public static void RefreshBoard()
    {
        board = new Pieces[][]{
            {Pieces.empty},
            {Pieces.empty,Pieces.empty,Pieces.empty},
            {Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty},
            {Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty},
            {Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty,Pieces.empty}
        };

        finished = false;
    }

    public static boolean Rematch()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println();
        System.out.print("REMATCH? Y/N: ");
        String input = scan.nextLine();
        if(input.toUpperCase().equals("N")) 
            return false;
        else
            return true;
    }

    public static void InitializePlayers()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("-=- Welcome to 3 Player Tic Tac Toe! -=-");
        System.out.print("PLAYER 1 NAME: ");
        players[0] = new TTTPlayer(TTTVisuals.RED + scan.nextLine()+ TTTVisuals.LIGHT, Pieces.xes);
        System.out.print("PLAYER 2 NAME: ");
        players[1] = new TTTPlayer(TTTVisuals.BLUE + scan.nextLine()+ TTTVisuals.LIGHT, Pieces.ohs);
        System.out.print("PLAYER 3 NAME: ");
        players[2] = new TTTPlayer(TTTVisuals.GREEN + scan.nextLine() + TTTVisuals.LIGHT, Pieces.pluses);
    }

    public static void PlacePiece()
    {
        System.out.println(players[curPlayer].getName() + ", type ROW and INDEX of your move, seperated by a COMMA. [EX: 2,1]");
        players[curPlayer].makeMove(board);

        finished = checkForWinner(players[curPlayer].getPiece());

        if(!finished)
        {
            curPlayer++;
            if(curPlayer > 2) 
                curPlayer = 0;
        }
    }

    public static boolean checkForWinner(Pieces p)
    {
        //checking for diagonals that go down left
        int inARow = 0;
        for(int vert = 0; vert < board.length; vert++)
        {
            for(int offset = vert;offset<board[vert].length;offset++)
            {
                for(int row = vert; row < board.length;row++)
                {
                    if(board[row][offset] == p)
                        inARow++;
                    else
                        inARow = 0;
    
                    if(inARow >= 4)
                        return true;
                }

                inARow = 0;
            }
        }

        inARow = 0;


        //checking for diagonals that go down right
        for(int vert = 0; vert < board.length; vert++)
        {
            for(int offset = vert;offset<board[vert].length;offset++)
            {
                for(int row = vert; row < board.length;row++)
                {
                    if(board[row][board[row].length - 1 - offset] == p)
                        inARow++;
                    else
                        inARow = 0;
    
                    if(inARow >= 4)
                        return true;
                }

                inARow = 0;
            }
        }

        inARow = 0;


        //checking for horizontals
        for(int vert = 0; vert < board.length; vert++)
        {
            if(board[vert].length >= 4)
            {
                for(int row = 0; row < board[vert].length;row++)
                {
                    if(board[vert][row] == p)
                        inARow++;
                    else
                        inARow = 0;
    
                    if(inARow >= 4)
                        return true;
                }
            }
        }


        return false;
    }
}

enum Pieces
{
    empty,
    xes,
    ohs,
    pluses
}
