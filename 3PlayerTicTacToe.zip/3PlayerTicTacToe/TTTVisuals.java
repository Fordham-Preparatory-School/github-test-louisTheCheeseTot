public class TTTVisuals
{   

    public static final String LIGHT = "\u001B[37m";
    public static final String DARK = "\u001B[30m";

    public static final String RED = "\u001B[31m";
    public static final String GREEN = "\u001B[32m";
    public static final String BLUE = "\u001B[34m";

    public static void PrintBoard()
    {
        boolean onLight = true;
        int lines = TTTGameManager.board.length;
        int spacesAtBeginning = lines;
        System.out.println();
        
        //make the top half of the diamond
        for(int i = 0; i < lines; i++)
        {
            System.out.print(i + 1);

            //create the adequate amount of offset
            for(int j =0;j<spacesAtBeginning;j++)
            {
                System.out.print("  ");
            }
            
            //loop through (1 -> line num) amount
            //of asterisks
            for(int k = 0; k < 1 + (i * 2); k++)
            {
                String charChosen = "@ ";
                if(TTTGameManager.board[i][k] == Pieces.xes)
                    charChosen = RED + "X ";
                if(TTTGameManager.board[i][k] == Pieces.ohs)
                    charChosen = BLUE + "O ";
                if(TTTGameManager.board[i][k] == Pieces.pluses)
                    charChosen = GREEN + "+ ";

                if(charChosen.equals("@ "))
                {
                    if(onLight )
                        System.out.print(LIGHT + charChosen);
                    else
                        System.out.print(DARK + charChosen);
                }
                else
                {
                    System.out.print(charChosen + (onLight ? LIGHT : DARK));
                }

                onLight = !onLight;
            }

            onLight = !onLight;
            
            //bring us down a line; reduce starting offset
            System.out.println();
            spacesAtBeginning--;
        }
    }
}
