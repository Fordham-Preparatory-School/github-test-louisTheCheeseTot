import java.util.Scanner;

public class TTTPlayer
{
    String playerName;
    Pieces piece;

    public TTTPlayer(String name, Pieces p)
    {
        playerName = name;
        piece = p;
    }

    public Pieces getPiece()
    {
        return piece;
    }

    public String getName()
    {
        return playerName;
    }

    public void makeMove(Pieces[][] board)
    {
        boolean valid = false;

        Scanner scan = new Scanner(System.in);
        String[] inputs = new String[2];
        int[] vals = new int[inputs.length];
        while(!valid)
        {
            String nextLine = scan.nextLine();
            //incase we accidentally write a space
            if(nextLine.contains(" ")) 
                inputs = nextLine.split(", ");
            else
                inputs = nextLine.split(",");

            for(int i =0;i<inputs.length;i++)
            {
                vals[i] = Integer.parseInt(inputs[i]);
            }

            //catching errors
            if(vals[0] <= board.length && vals[0] > 0 && vals[1] <= board[vals[0] - 1].length && vals[1] > 0)
            {
                if(board[vals[0] - 1][vals[1] - 1] != Pieces.empty)
                {
                    System.out.println("SPOT TAKEN! Try again...");
                }
                else
                {
                    valid = true;
                }
            }
            else
            {
                System.out.println("INVALID POSITION! Try again...");
            }
        }


        board[vals[0] - 1][vals[1] - 1] = piece;
    }
}